import javax.swing.*;
import java.awt.*;

public class BarGraph extends JPanel
{ 
   private String input01 = JOptionPane.showInputDialog("Please type the title of your graph: "); //The title
   private String input02= JOptionPane.showInputDialog("Please type the value of the largest bar you will draw"); //The value of the largest bar 
   private int largestValue = new Integer(input02).intValue();
    
   private String input11 = JOptionPane.showInputDialog("Please type the name of the first bar: "); //First Bar
   private String input12= JOptionPane.showInputDialog("Please type the value of the first bar:");  //The value of the first bar
   private int firstValue = new Integer(input12).intValue();
   
   private String input21 = JOptionPane.showInputDialog("Please type the name of the second bar: ");  //Second Bar
   private String input22= JOptionPane.showInputDialog("Please type the value of the second bar:");  //The value of the second bar
   private int secondValue = new Integer(input22).intValue();

   private String input31 = JOptionPane.showInputDialog("Please type the name of the third bar: ");//Third Bar
   private String input32= JOptionPane.showInputDialog("Please type the value of the third bar:"); //The value of the third bar
   private int thirdValue = new Integer(input32).intValue();

   private String input41 = JOptionPane.showInputDialog("Please type the name of the fourth bar: "); //Fourth Bar
   private String input42= JOptionPane.showInputDialog("Please type the value of the fourth bar:"); //The value of the fourth bar
   private int fourthValue = new Integer(input42).intValue();
 
   private String input51 = JOptionPane.showInputDialog("Please type the name of the fifth bar: ");//Fifth Bar
   private String input52= JOptionPane.showInputDialog("Please type the value of the fifth bar:"); //The value of the fifth bar
   private int fifthValue = new Integer(input52).intValue();
      
   private String input61 = JOptionPane.showInputDialog("Please type the name of the sixth bar: ");//Sixth Bar
   private String input62= JOptionPane.showInputDialog("Please type the value of the sixth bar:"); //The value of the sixth bar
   private int sixthValue = new Integer(input62).intValue();

  public BarGraph()
   { int width =400;
      JFrame frame = new JFrame(); // the frame's width
      frame.getContentPane().add(this);
      frame.setSize(width,width);
      frame.setTitle("BarGraph");
      frame.setVisible(true);
   }
   public void paintComponent(Graphics g)
   { g.setColor(Color.black);
      int width =400;
      int diference = 260;
      int x_pos =40; // x-position of graph
      int y_pos=2*width/3; // y-position of graph
      int y_height=10;
      int distance=60;
      String top_label = y_height +"";
      String labelt=input01;
      String label01=input11;
      String label02=input21;
      String label03=input31;
      String label04=input41;
      String label05=input51;
      String label06=input61;
      
      int height1 =firstValue; 
      int height2 =secondValue ; 
      int height3 =thirdValue ; 
      int height4 =fourthValue ; 
      int height5 =fifthValue ; 
      int height6 =sixthValue ; 
        
      int scale_factor = 3;
      height1 = height1*scale_factor;
      height2 = height2*scale_factor;
      height3 = height3*scale_factor;
      height4 = height4*scale_factor;
      height5 = height5*scale_factor;
      height6 = height6*scale_factor;      
          
      g.drawString(labelt,20,50);
      g.drawString(largestValue+"",20,70);
        
      g.drawString("0",x_pos-20,y_pos+5);
      g.drawLine(x_pos, y_pos, x_pos+diference, y_pos); // draw x-axis
      g.drawLine(x_pos ,y_pos-y_height, x_pos, y_pos); // draw y-axis
      g.drawString(top_label, x_pos-20, y_pos-y_height*scale_factor+5);
         
      g.setColor(Color.red);
      g.fillRect(x_pos, y_pos-height1, distance,height1); // draw bar1
      g.drawString(label01, x_pos, y_pos+10);
         
      g.setColor(Color.gray);
      g.fillRect(x_pos+distance, y_pos-height2, distance,height2); // draw bar2
      g.drawString(label02,x_pos+distance,y_pos+10);
         
      g.setColor(Color.green);
      g.fillRect(x_pos+distance*2,y_pos-height3,distance,height3); // draw bar3
      g.drawString(label03,x_pos+distance*2,y_pos+10);
         
      g.setColor(Color.orange);
      g.fillRect(x_pos+distance*3,y_pos-height4,distance,height4); // draw bar4
      g.drawString(label04,x_pos+distance*3,y_pos+10);
         
      g.setColor(Color.pink);
      g.fillRect(x_pos+distance*4,y_pos-height5,distance,height5); // draw bar5
      g.drawString(label05,x_pos+distance*4,y_pos+10);
         
      g.setColor(Color.blue);
      g.fillRect(x_pos+distance*5,y_pos-height6,distance,height6); // draw bar6
      g.drawString(label06,x_pos+distance*5,y_pos+10);
   }
     /** The main method assembles the graph in its frame.*/
   public static void main(String[] args)
   { new BarGraph(); }
}

  
